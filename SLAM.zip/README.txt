I dont know what game you will use the voices so I put in all source games. If some game is not of your interest, feel free to delete the folder from the SLAM. 
-----------------------------------------------
HOW TO USE:

1- First press start
2- Then in the developer console type exec slam
3- Depending of your game, maybe diferences enabling the console in some games.
4- Press the bind of the corresponding voice line you want to play 
5- Press X 